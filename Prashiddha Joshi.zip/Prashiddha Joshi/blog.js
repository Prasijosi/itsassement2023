function addComment(form) {
    const commentInput = form.elements.comment;
    const commentText = commentInput.value.trim();

    if (commentText === '') {
        alert('Please enter a comment.');
        return false;
    }

    const commentDiv = document.createElement('div');
    commentDiv.textContent = commentText;
    form.parentElement.querySelector('.comments').appendChild(commentDiv);

    commentInput.value = '';
    return false;
}