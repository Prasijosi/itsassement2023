< !DOCTYPE html >
    <
    html >
    <
    head >
    <
    title > Variable Types in JavaScript < /title> <
    /head> <
    body >
    <
    script >
    // Define variables with different data types
    var numericValue = 42;
var floatValue = 3.14;
var stringValue = "Hello, World!";
var booleanValue = true;

// Display the variables using document.write()
document.write("<h3>Numeric Value:</h3>");
document.write(numericValue);

document.write("<h3>Float Value:</h3>");
document.write(floatValue);

document.write("<h3>String Value:</h3>");
document.write(stringValue);

document.write("<h3>Boolean Value:</h3>");
document.write(booleanValue); <
/script> <
/body> <
/html>